# THU_emp
清华大学近代物理实验报告LaTeX模板（非官方）

A Latex template for experiments in modern physics of Tsinghua University.

THU_emp : Tsinghua University Experiments in Modern Physics

thuemp.cls 模板文件

TempExample.tex 正文内容

TempExample.bib 参考文献

image 文件夹下是正文中用到的图片文件